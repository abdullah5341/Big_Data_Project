# Explainable Diabetes Risk Screening (CDC BRFSS 2015)

Student: Abdullah Mahmood (i26043871)

Compares Logistic Regression, Random Forest and XGBoost for predicting diabetes risk from
health-survey answers, with SHAP explanations, error analysis, feature selection, a scalability
test and a Streamlit web app.

## Dataset
CDC Diabetes Health Indicators, UCI Machine Learning Repository dataset 891
(https://archive.ics.uci.edu/dataset/891/cdc+diabetes+health+indicators, DOI 10.24432/C53919):
253,680 survey answers, 21 features, target `Diabetes_binary`.

- **Download:** `python src/data_loader.py` downloads the full dataset into `data/raw/`
  (internet connection needed). It can also be downloaded by hand from the link above.
- **Sample:** `data/sample/sample_1000_rows.csv` contains 1,000 random rows to show the format.
  The full dataset is needed to reproduce the results.

## Setup
Tested on Python 3.14.8. `requirements.txt` pins the exact library versions.
```bash
python -m venv .venv
# Windows: .venv\Scripts\activate    |  Linux/macOS: source .venv/bin/activate
pip install -r requirements.txt
```

## Run the web app
```bash
streamlit run app/app.py
```
Uses the saved model `models/xgboost.joblib` (included). Pages: **Risk check** (questionnaire,
risk score, risk band, explanation) and **Model performance** (shown after running steps 1-4 below).

## Reproduce all results
```bash
python src/run_pipeline.py     # runs steps 1-8 below (about 15-20 minutes)
```
| Step | Command | What it does |
|---|---|---|
| 1 | `python src/data_loader.py` | Downloads the dataset and prints a quality report |
| 2 | `python src/preprocess.py` | Removes duplicates, adds 2 features, stratified 70/15/15 split |
| 3 | `python src/train.py` | Tunes each model with 5-fold CV on train; chooses the threshold on validation |
| 4 | `python src/evaluate.py` | Scores every model once on the test set |
| 5 | `python src/explain.py` | SHAP explanations |
| 6 | `python src/feature_selection.py` | Finds how many features are needed |
| 7 | `python src/scalability.py` | Training time on 25%, 50% and 100% of the data |
| 8 | `python src/make_architecture_diagram.py` | System architecture figure |

Outputs are written to `data/processed/`, `models/`, `results/` and `figures/` (created automatically).
Notebooks (`jupyter notebook`): `notebooks/01_eda.ipynb` (needs step 1) and
`notebooks/02_error_analysis.ipynb` (needs step 4).
All randomness uses `RANDOM_STATE = 42` (`src/config.py`), so every run gives the same results.

## How data leakage is prevented
- Exact duplicates are removed before splitting; a check proves no row is in two splits.
- Scaling sits inside an sklearn `Pipeline`, so it only learns from the training folds.
- Class imbalance is handled with class weights (no synthetic rows).
- Settings are tuned on training data only, the threshold is chosen on validation, and the test set is used once.

## Libraries used
pandas, NumPy, SciPy, scikit-learn, XGBoost, SHAP, matplotlib, seaborn, Streamlit, joblib, ucimlrepo, Jupyter.

## Disclaimer
Research prototype for screening support only. It is not a medical diagnosis.
